/*
 * BedWars1058 - A bed wars mini-game.
 * Copyright (C) 2021 Andrei Dascălu
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Contact e-mail: andrew.dascalu@gmail.com
 */

package com.andrei1058.bedwars.shop.editor;

import com.andrei1058.bedwars.BedWars;
import com.andrei1058.bedwars.api.configuration.ConfigPath;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Visual in-game shop editor. Allows admins to create / edit shop categories,
 * content and tiers, set prices and currencies, and drag items from their own
 * inventory (including modded items with full NBT) into the shop.
 */
public class ShopEditor {

    private static final Map<UUID, Session> SESSIONS = new HashMap<>();

    /* Menu titles */
    static final String TITLE_ROOT = "§8§l商店编辑器 - 主菜单";
    static final String TITLE_CATEGORY = "§8§l商店编辑器 - 分类";
    static final String TITLE_CONTENT = "§8§l商店编辑器 - 商品";
    static final String TITLE_TIER = "§8§l商店编辑器 - 等级";

    /* Button slots */
    static final int CLOSE_SLOT = 53;
    static final int BACK_SLOT = 49;
    static final int ROOT_ADD_SLOT = 45;
    static final int ROOT_SAVE_SLOT = 47;
    static final int CATEGORY_ADD_CONTENT = 45;
    static final int CATEGORY_DELETE = 47;
    static final int CATEGORY_ICON = 40;
    static final int CONTENT_ADD_TIER = 45;
    static final int CONTENT_DELETE = 47;
    static final int CONTENT_PERMANENT = 50;
    static final int CONTENT_UNBREAKABLE = 51;
    static final int TIER_PREVIEW = 19;
    static final int TIER_BUY_ITEM = 25;
    static final int TIER_PRICE_MINUS10 = 10;
    static final int TIER_PRICE_MINUS1 = 11;
    static final int TIER_PRICE_DISPLAY = 13;
    static final int TIER_PRICE_PLUS1 = 14;
    static final int TIER_PRICE_PLUS10 = 15;
    static final int TIER_CURRENCY = 28;
    static final int TIER_AUTO_EQUIP = 31;
    static final int TIER_DELETE = 37;

    static final String[] CURRENCIES = {"iron", "gold", "diamond", "emerald", "vault"};

    private ShopEditor() {
    }

    /* ===================== session management ===================== */

    static Session getSession(Player p) {
        return SESSIONS.get(p.getUniqueId());
    }

    static Session getOrCreateSession(Player p) {
        Session s = SESSIONS.get(p.getUniqueId());
        if (s == null) {
            s = new Session();
            SESSIONS.put(p.getUniqueId(), s);
        }
        return s;
    }

    static void removeSession(Player p) {
        SESSIONS.remove(p.getUniqueId());
    }

    static boolean isEditorInventory(InventoryView view) {
        if (view == null) return false;
        String title = view.getTitle();
        return title != null && title.contains("商店编辑器");
    }

    static final class Session {
        String category;   // null when at root
        String content;    // null when not editing a content
        String tier;       // null when not editing a tier
        String awaiting;   // null | "category-name" | "content-name" | "price"
        String pendingConfirm; // used for delete confirmation
    }

    /* ===================== open entry points ===================== */

    public static void open(Player p) {
        Session s = getOrCreateSession(p);
        s.category = null;
        s.content = null;
        s.tier = null;
        s.awaiting = null;
        s.pendingConfirm = null;
        openRoot(p, s);
    }

    static void openRoot(Player p, Session s) {
        Inventory inv = Bukkit.createInventory(null, 54, TITLE_ROOT);
        fill(inv);

        List<String> categories = getCategoryNames();
        int i = 0;
        for (String cat : categories) {
            if (i >= 8) break;
            ItemStack icon = readItem(cat + ConfigPath.SHOP_CATEGORY_ITEM_MATERIAL, cat + ConfigPath.SHOP_CATEGORY_ITEM_NBT, "STONE");
            ItemMeta im = icon.getItemMeta();
            if (im != null) {
                im.setDisplayName("§e" + cat);
                List<String> lore = new ArrayList<>();
                lore.add("§7点击编辑此分类");
                im.setLore(lore);
                icon.setItemMeta(im);
            }
            inv.setItem(i, icon);
            i++;
        }

        inv.setItem(ROOT_ADD_SLOT, button(Material.EMERALD_BLOCK, "§a§l添加分类", "§7创建一个新的商店分类"));
        inv.setItem(ROOT_SAVE_SLOT, button(Material.EMERALD, "§6§l保存并重载", "§7把修改写入 shop.yml 并重载商店"));
        inv.setItem(CLOSE_SLOT, button(Material.BARRIER, "§c关闭", null));

        p.openInventory(inv);
    }

    static void openCategory(Player p, Session s) {
        Inventory inv = Bukkit.createInventory(null, 54, TITLE_CATEGORY + ": " + s.category);
        fill(inv);

        List<String> contents = getContentNames(s.category);
        int i = 0;
        for (String content : contents) {
            if (i >= 36) break;
            String tierNode = contentTierNode(s.category, content, "tier1");
            ItemStack icon = readItem(tierNode + ConfigPath.SHOP_CONTENT_TIER_ITEM_MATERIAL,
                    tierNode + ConfigPath.SHOP_CONTENT_TIER_ITEM_NBT, "STONE");
            ItemMeta im = icon.getItemMeta();
            if (im != null) {
                im.setDisplayName("§e" + content);
                List<String> lore = new ArrayList<>();
                lore.add("§7点击编辑此商品");
                im.setLore(lore);
                icon.setItemMeta(im);
            }
            inv.setItem(i, icon);
            i++;
        }

        ItemStack catIcon = readItem(s.category + ConfigPath.SHOP_CATEGORY_ITEM_MATERIAL,
                s.category + ConfigPath.SHOP_CATEGORY_ITEM_NBT, "STONE");
        ItemMeta cm = catIcon.getItemMeta();
        if (cm != null) {
            cm.setDisplayName("§b分类图标");
            List<String> lore = new ArrayList<>();
            lore.add("§7点击并用手上的物品替换图标");
            lore.add("§7(可从下方背包拾取物品)");
            cm.setLore(lore);
            catIcon.setItemMeta(cm);
        }
        inv.setItem(CATEGORY_ICON, catIcon);

        inv.setItem(CATEGORY_ADD_CONTENT, button(Material.EMERALD_BLOCK, "§a§l添加商品", "§7创建一个新的商品"));
        inv.setItem(CATEGORY_DELETE, button(Material.REDSTONE_BLOCK, "§c§l删除分类", "§7点击两次确认删除"));
        inv.setItem(BACK_SLOT, button(Material.ARROW, "§e返回", null));
        inv.setItem(CLOSE_SLOT, button(Material.BARRIER, "§c关闭", null));

        p.openInventory(inv);
    }

    static void openContent(Player p, Session s) {
        Inventory inv = Bukkit.createInventory(null, 54, TITLE_CONTENT + ": " + s.category + "/" + s.content);
        fill(inv);

        List<String> tiers = getTierNames(s.category, s.content);
        int i = 0;
        for (String tier : tiers) {
            if (i >= 36) break;
            String tierNode = contentTierNode(s.category, s.content, tier);
            ItemStack icon = readItem(tierNode + ConfigPath.SHOP_CONTENT_TIER_ITEM_MATERIAL,
                    tierNode + ConfigPath.SHOP_CONTENT_TIER_ITEM_NBT, "STONE");
            int price = yml().getInt(tierNode + ConfigPath.SHOP_CONTENT_TIER_SETTINGS_COST, 0);
            String currency = yml().getString(tierNode + ConfigPath.SHOP_CONTENT_TIER_SETTINGS_CURRENCY, "iron");
            ItemMeta im = icon.getItemMeta();
            if (im != null) {
                im.setDisplayName("§e" + tier);
                List<String> lore = new ArrayList<>();
                lore.add("§7价格: §f" + price + " " + currency);
                lore.add("§7点击编辑此等级");
                im.setLore(lore);
                icon.setItemMeta(im);
            }
            inv.setItem(i, icon);
            i++;
        }

        String contentNode = contentNode(s.category, s.content);
        boolean permanent = yml().getBoolean(contentNode + "." + ConfigPath.SHOP_CATEGORY_CONTENT_IS_PERMANENT, false);
        boolean unbreakable = yml().getBoolean(contentNode + "." + ConfigPath.SHOP_CATEGORY_CONTENT_IS_UNBREAKABLE, false);

        inv.setItem(CONTENT_PERMANENT, toggle(Material.ANVIL, "§e永久物品", permanent, "§7购买后不会因升级/死亡被替换"));
        inv.setItem(CONTENT_UNBREAKABLE, toggle(Material.DIAMOND_PICKAXE, "§e不可破坏", unbreakable, "§7物品不可被破坏"));
        inv.setItem(CONTENT_ADD_TIER, button(Material.EMERALD_BLOCK, "§a§l添加等级", "§7追加一个 tier"));
        inv.setItem(CONTENT_DELETE, button(Material.REDSTONE_BLOCK, "§c§l删除商品", "§7点击两次确认删除"));
        inv.setItem(BACK_SLOT, button(Material.ARROW, "§e返回", null));
        inv.setItem(CLOSE_SLOT, button(Material.BARRIER, "§c关闭", null));

        p.openInventory(inv);
    }

    static void openTier(Player p, Session s) {
        Inventory inv = Bukkit.createInventory(null, 54, TITLE_TIER + ": " + s.content + "/" + s.tier);
        fill(inv);

        String tierNode = contentTierNode(s.category, s.content, s.tier);

        ItemStack preview = readItem(tierNode + ConfigPath.SHOP_CONTENT_TIER_ITEM_MATERIAL,
                tierNode + ConfigPath.SHOP_CONTENT_TIER_ITEM_NBT, "STONE");
        ItemMeta pm = preview.getItemMeta();
        if (pm != null) {
            pm.setDisplayName("§b§l商店显示物品 (Preview)");
            List<String> lore = new ArrayList<>();
            lore.add("§7这是商店里展示的图标");
            lore.add("§7点击并用手上物品替换");
            pm.setLore(lore);
            preview.setItemMeta(pm);
        }
        inv.setItem(TIER_PREVIEW, preview);

        ItemStack buyItem = readItem(tierNode + ".buy-items.item1.material", tierNode + ".buy-items.item1.nbt", "STONE");
        ItemMeta bm = buyItem.getItemMeta();
        if (bm != null) {
            bm.setDisplayName("§b§l购买获得物品 (Buy Item)");
            List<String> lore = new ArrayList<>();
            lore.add("§7这是玩家购买后拿到的物品");
            lore.add("§7点击并用手上物品替换");
            bm.setLore(lore);
            buyItem.setItemMeta(bm);
        }
        inv.setItem(TIER_BUY_ITEM, buyItem);

        int price = yml().getInt(tierNode + ConfigPath.SHOP_CONTENT_TIER_SETTINGS_COST, 0);
        String currency = yml().getString(tierNode + ConfigPath.SHOP_CONTENT_TIER_SETTINGS_CURRENCY, "iron");
        boolean autoEquip = yml().getBoolean(tierNode + ".buy-items.item1.auto-equip", false);

        inv.setItem(TIER_PRICE_MINUS10, button(Material.REDSTONE, "§c价格 -10", null));
        inv.setItem(TIER_PRICE_MINUS1, button(Material.REDSTONE, "§c价格 -1", null));
        inv.setItem(TIER_PRICE_DISPLAY, button(Material.GOLD_INGOT, "§a价格: §f" + price + " §7(" + currency + ")", "§7点击后输入新价格"));
        inv.setItem(TIER_PRICE_PLUS1, button(Material.SLIME_BALL, "§a价格 +1", null));
        inv.setItem(TIER_PRICE_PLUS10, button(Material.SLIME_BALL, "§a价格 +10", null));

        inv.setItem(TIER_CURRENCY, button(currencyMaterial(currency), "§e货币: §f" + currency, "§7点击切换货币"));
        inv.setItem(TIER_AUTO_EQUIP, toggle(Material.valueOf(BedWars.getForCurrentVersion("DIAMOND_CHESTPLATE", "DIAMOND_CHESTPLATE", "DIAMOND_CHESTPLATE")),
                "§e自动穿戴", autoEquip, "§7购买后自动装备(护甲)"));
        inv.setItem(TIER_DELETE, button(Material.REDSTONE_BLOCK, "§c§l删除等级", "§7点击两次确认删除"));
        inv.setItem(BACK_SLOT, button(Material.ARROW, "§e返回", null));
        inv.setItem(CLOSE_SLOT, button(Material.BARRIER, "§c关闭", null));

        p.openInventory(inv);
    }

    /* ===================== chat input ===================== */

    static void onChat(Player p, String message) {
        Session s = getSession(p);
        if (s == null) return;
        if (s.awaiting == null) return;

        String input = ChatColor.stripColor(message).trim();
        if (s.awaiting.equals("price")) {
            int price;
            try {
                price = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                p.sendMessage("§c价格必须是数字!");
                return;
            }
            if (price < 0) price = 0;
            String tierNode = contentTierNode(s.category, s.content, s.tier);
            yml().set(tierNode + ConfigPath.SHOP_CONTENT_TIER_SETTINGS_COST, price);
            save();
            s.awaiting = null;
            p.sendMessage("§a价格已设为 " + price);
            openTier(p, s);
            return;
        }

        if (s.awaiting.equals("category-name")) {
            String name = sanitize(input);
            if (name.isEmpty()) {
                p.sendMessage("§c名称不能为空!");
                return;
            }
            if (yml().get(name) != null) {
                p.sendMessage("§c该分类已存在!");
                return;
            }
            if (nextCategorySlot() == -1) {
                p.sendMessage("§c分类数量已达上限 (8)!");
                return;
            }
            createCategory(name);
            save();
            s.awaiting = null;
            s.category = name;
            s.content = null;
            s.tier = null;
            p.sendMessage("§a已创建分类 " + name);
            openCategory(p, s);
            return;
        }

        if (s.awaiting.equals("content-name")) {
            String name = sanitize(input);
            if (name.isEmpty()) {
                p.sendMessage("§c名称不能为空!");
                return;
            }
            String contentNode = contentNode(s.category, name);
            if (yml().get(contentNode) != null) {
                p.sendMessage("§c该商品已存在!");
                return;
            }
            createContent(s.category, name);
            save();
            s.awaiting = null;
            s.content = name;
            s.tier = null;
            p.sendMessage("§a已创建商品 " + name);
            openContent(p, s);
            return;
        }

        s.awaiting = null;
    }

    /* ===================== config helpers ===================== */

    static YamlConfiguration yml() {
        return BedWars.shop.getYml();
    }

    static void save() {
        BedWars.shop.save();
    }

    static String contentNode(String category, String content) {
        return category + ConfigPath.SHOP_CATEGORY_CONTENT_PATH + "." + content;
    }

    static String contentTierNode(String category, String content, String tier) {
        return contentNode(category, content) + "." + ConfigPath.SHOP_CATEGORY_CONTENT_CONTENT_TIERS + "." + tier;
    }

    static List<String> getCategoryNames() {
        List<String> list = new ArrayList<>();
        for (String key : yml().getConfigurationSection("").getKeys(false)) {
            if (key.equalsIgnoreCase(ConfigPath.SHOP_SETTINGS_PATH)) continue;
            if (key.equals(ConfigPath.SHOP_QUICK_DEFAULTS_PATH)) continue;
            if (key.equalsIgnoreCase(ConfigPath.SHOP_SPECIALS_PATH)) continue;
            list.add(key);
        }
        return list;
    }

    static List<String> getContentNames(String category) {
        List<String> list = new ArrayList<>();
        String path = category + ConfigPath.SHOP_CATEGORY_CONTENT_PATH;
        if (yml().getConfigurationSection(path) == null) return list;
        for (String key : yml().getConfigurationSection(path).getKeys(false)) {
            list.add(key);
        }
        return list;
    }

    static List<String> getTierNames(String category, String content) {
        List<String> list = new ArrayList<>();
        String path = contentNode(category, content) + "." + ConfigPath.SHOP_CATEGORY_CONTENT_CONTENT_TIERS;
        if (yml().getConfigurationSection(path) == null) return list;
        for (String key : yml().getConfigurationSection(path).getKeys(false)) {
            list.add(key);
        }
        return list;
    }

    static int nextCategorySlot() {
        for (int slot = 1; slot <= 8; slot++) {
            boolean used = false;
            for (String cat : getCategoryNames()) {
                if (yml().getInt(cat + ConfigPath.SHOP_CATEGORY_SLOT, -1) == slot) {
                    used = true;
                    break;
                }
            }
            if (!used) return slot;
        }
        return -1;
    }

    static int nextContentSlot(String category) {
        boolean[] used = new boolean[54];
        for (String content : getContentNames(category)) {
            int slot = yml().getInt(contentNode(category, content) + "." + ConfigPath.SHOP_CATEGORY_CONTENT_CONTENT_SLOT, -1);
            if (slot >= 0 && slot < 54) used[slot] = true;
        }
        for (int slot = 19; slot <= 52; slot++) {
            if (!used[slot]) return slot;
        }
        return -1;
    }

    static void createCategory(String name) {
        int slot = nextCategorySlot();
        if (slot == -1) slot = 1;
        yml().set(name + ConfigPath.SHOP_CATEGORY_SLOT, slot);
        writeItem(name + ".category-item", new ItemStack(Material.STONE));
        // Ensure the category always has a (possibly empty) content section, so the
        // core shop loader never hits a missing ".category-content" node.
        yml().createSection(name + ConfigPath.SHOP_CATEGORY_CONTENT_PATH);
    }

    static void createContent(String category, String content) {
        String node = contentNode(category, content);
        int slot = nextContentSlot(category);
        if (slot == -1) slot = 19;
        yml().set(node + "." + ConfigPath.SHOP_CATEGORY_CONTENT_CONTENT_SLOT, slot);
        yml().set(node + "." + ConfigPath.SHOP_CATEGORY_CONTENT_IS_PERMANENT, false);
        yml().set(node + "." + ConfigPath.SHOP_CATEGORY_CONTENT_IS_DOWNGRADABLE, false);
        yml().set(node + "." + ConfigPath.SHOP_CATEGORY_CONTENT_IS_UNBREAKABLE, false);
        yml().set(node + "." + ConfigPath.SHOP_CATEGORY_CONTENT_WEIGHT, 0);
        createTier(category, content, "tier1");
    }

    static void createTier(String category, String content, String tier) {
        String node = contentTierNode(category, content, tier);
        writeItem(node + ".tier-item", new ItemStack(Material.STONE));
        yml().set(node + ConfigPath.SHOP_CONTENT_TIER_SETTINGS_COST, 1);
        yml().set(node + ConfigPath.SHOP_CONTENT_TIER_SETTINGS_CURRENCY, "iron");
        writeBuyItem(node + ".buy-items.item1", new ItemStack(Material.STONE));
    }

    static void deleteCategory(String category) {
        yml().set(category, null);
    }

    static void deleteContent(String category, String content) {
        yml().set(contentNode(category, content), null);
    }

    static void deleteTier(String category, String content, String tier) {
        yml().set(contentTierNode(category, content, tier), null);
    }

    /**
     * Write a full item to a "preview" style node (category-item / tier-item).
     * Stores both the base64 NBT (mod items) and the fallback material.
     */
    static void writeItem(String node, ItemStack item) {
        if (item == null || item.getType() == Material.AIR) {
            item = new ItemStack(Material.STONE);
        }
        String nbt = BedWars.nms.serializeItemStack(item);
        yml().set(node + ".nbt", nbt);
        yml().set(node + ".material", item.getType().name());
        yml().set(node + ".data", 0);
        yml().set(node + ".amount", item.getAmount());
        yml().set(node + ".enchanted", false);
        yml().set(node + ".potion-display", null);
        yml().set(node + ".potion-color", null);
    }

    /**
     * Write a full item to a buy-item node.
     */
    static void writeBuyItem(String node, ItemStack item) {
        if (item == null || item.getType() == Material.AIR) {
            item = new ItemStack(Material.STONE);
        }
        String nbt = BedWars.nms.serializeItemStack(item);
        yml().set(node + ".nbt", nbt);
        yml().set(node + ".material", item.getType().name());
        yml().set(node + ".data", 0);
        yml().set(node + ".amount", item.getAmount());
        yml().set(node + ".enchanted", false);
        yml().set(node + ".name", null);
        yml().set(node + ".enchants", null);
        yml().set(node + ".potion", null);
        yml().set(node + ".potion-color", null);
    }

    static ItemStack readItem(String materialPath, String nbtPath, String defaultMaterial) {
        String nbt = yml().getString(nbtPath);
        if (nbt != null && !nbt.isEmpty()) {
            ItemStack i = BedWars.nms.deserializeItemStack(nbt);
            if (i != null) return i;
        }
        String mat = yml().getString(materialPath);
        int amount = yml().getInt(materialPath.replace(".material", ".amount"), 1);
        if (mat == null || mat.isEmpty()) mat = defaultMaterial;
        try {
            return new ItemStack(Material.valueOf(mat), amount);
        } catch (Exception e) {
            return new ItemStack(Material.BARRIER);
        }
    }

    static Material currencyMaterial(String currency) {
        switch (currency) {
            case "gold":
                return Material.GOLD_INGOT;
            case "diamond":
                return Material.DIAMOND;
            case "emerald":
                return Material.EMERALD;
            case "vault":
                return Material.valueOf(BedWars.getForCurrentVersion("GOLD_NUGGET", "GOLD_NUGGET", "GOLD_NUGGET"));
            default:
                return Material.IRON_INGOT;
        }
    }

    static String currencyString(Material material) {
        switch (material) {
            case GOLD_INGOT:
                return "gold";
            case DIAMOND:
                return "diamond";
            case EMERALD:
                return "emerald";
            case AIR:
                return "vault";
            default:
                return "iron";
        }
    }

    static String nextCurrency(String current) {
        for (int i = 0; i < CURRENCIES.length; i++) {
            if (CURRENCIES[i].equalsIgnoreCase(current)) {
                return CURRENCIES[(i + 1) % CURRENCIES.length];
            }
        }
        return "iron";
    }

    static String sanitize(String name) {
        return name.toLowerCase().replaceAll("[^a-z0-9_-]", "-").replaceAll("-{2,}", "-")
                .replaceAll("^[-_]+", "").replaceAll("[-_]+$", "");
    }

    /* ===================== UI helpers ===================== */

    private static void fill(Inventory inv) {
        Material pane = Material.valueOf(BedWars.getForCurrentVersion("STAINED_GLASS_PANE", "STAINED_GLASS_PANE", "BLACK_STAINED_GLASS_PANE"));
        ItemStack filler = new ItemStack(pane, 1);
        ItemMeta fm = filler.getItemMeta();
        if (fm != null) {
            fm.setDisplayName(" ");
            filler.setItemMeta(fm);
        }
        for (int i = 0; i < inv.getSize(); i++) {
            if (inv.getItem(i) == null || inv.getItem(i).getType() == Material.AIR) {
                inv.setItem(i, filler.clone());
            }
        }
    }

    private static ItemStack button(Material material, String name, String lore) {
        ItemStack i = new ItemStack(material, 1);
        ItemMeta im = i.getItemMeta();
        if (im != null) {
            im.setDisplayName(name);
            if (lore != null) {
                List<String> l = new ArrayList<>();
                l.add(lore);
                im.setLore(l);
            }
            i.setItemMeta(im);
        }
        return i;
    }

    private static ItemStack toggle(Material material, String name, boolean enabled, String lore) {
        ItemStack i = new ItemStack(material, 1);
        ItemMeta im = i.getItemMeta();
        if (im != null) {
            im.setDisplayName(name + ": " + (enabled ? "§a开启" : "§c关闭"));
            List<String> l = new ArrayList<>();
            l.add("§7当前: " + (enabled ? "§a开启" : "§c关闭"));
            l.add("§7点击切换");
            if (lore != null) l.add(lore);
            im.setLore(l);
            i.setItemMeta(im);
        }
        return i;
    }
}
