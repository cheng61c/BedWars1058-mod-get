/*
 * BedWars1058 - A bed wars mini-game.
 * Copyright (C) 2021 Andrei Dascălu
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Contact e-mail: andrew.dascalu@gmail.com
 */

package com.andrei1058.bedwars.shop.editor;

import com.andrei1058.bedwars.BedWars;
import com.andrei1058.bedwars.api.configuration.ConfigPath;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemStack;

import java.util.List;

/**
 * Handles the interactive part of the visual shop editor.
 */
public class ShopEditorListener implements Listener {

    @EventHandler(priority = EventPriority.HIGH)
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player)) return;
        Player p = (Player) e.getWhoClicked();
        ShopEditor.Session s = ShopEditor.getSession(p);
        if (s == null) return;

        Inventory top = e.getView().getTopInventory();
        if (!ShopEditor.isEditorInventory(e.getView())) return;

        e.setCancelled(true);

        // Pick an item from the player's own inventory (bottom section) onto the cursor.
        if (e.getClickedInventory() != null && e.getClickedInventory().getType() == InventoryType.PLAYER) {
            ItemStack cur = e.getCurrentItem();
            if (cur != null && cur.getType() != Material.AIR) {
                e.setCursor(cur.clone());
                p.sendMessage("§a已拾取物品 §f" + (cur.hasItemMeta() && cur.getItemMeta().hasDisplayName() ? cur.getItemMeta().getDisplayName() : cur.getType().name())
                        + "§a，点击商店里的物品槽位进行放置");
            }
            return;
        }

        int slot = e.getSlot();

        // Route by current editor state
        if (s.category == null) {
            handleRoot(p, s, e, slot);
        } else if (s.content == null) {
            handleCategory(p, s, e, slot);
        } else if (s.tier == null) {
            handleContent(p, s, e, slot);
        } else {
            handleTier(p, s, e, slot);
        }
    }

    private void handleRoot(Player p, ShopEditor.Session s, InventoryClickEvent e, int slot) {
        List<String> categories = ShopEditor.getCategoryNames();
        s.pendingConfirm = null;
        if (slot >= 0 && slot < 8 && slot < categories.size()) {
            s.category = categories.get(slot);
            s.content = null;
            s.tier = null;
            ShopEditor.openCategory(p, s);
            return;
        }
        if (slot == ShopEditor.ROOT_ADD_SLOT) {
            s.awaiting = "category-name";
            p.closeInventory();
            p.sendMessage("§a请在聊天栏输入新分类的名称 (例如 my-category)，输入 cancel 取消");
            return;
        }
        if (slot == ShopEditor.ROOT_SAVE_SLOT) {
            ShopEditor.save();
            BedWars.shop.reloadShop();
            p.sendMessage("§a商店已保存并重载!");
            reopen(p, () -> ShopEditor.openRoot(p, s));
            return;
        }
        if (slot == ShopEditor.CLOSE_SLOT) {
            p.closeInventory();
        }
    }

    private void handleCategory(Player p, ShopEditor.Session s, InventoryClickEvent e, int slot) {
        List<String> contents = ShopEditor.getContentNames(s.category);
        if (slot >= 0 && slot < 36 && slot < contents.size()) {
            s.pendingConfirm = null;
            s.content = contents.get(slot);
            s.tier = null;
            ShopEditor.openContent(p, s);
            return;
        }
        if (slot == ShopEditor.CATEGORY_ICON) {
            if (tryPlace(p, s, slot, e.getCursor())) {
                e.setCursor(null);
            }
            return;
        }
        if (slot == ShopEditor.CATEGORY_ADD_CONTENT) {
            s.pendingConfirm = null;
            s.awaiting = "content-name";
            p.closeInventory();
            p.sendMessage("§a请在聊天栏输入新商品的名称 (例如 my-item)，输入 cancel 取消");
            return;
        }
        if (slot == ShopEditor.CATEGORY_DELETE) {
            if (!"delete-category".equals(s.pendingConfirm)) {
                s.pendingConfirm = "delete-category";
                p.sendMessage("§c再次点击删除按钮确认删除分类 §f" + s.category);
            } else {
                ShopEditor.deleteCategory(s.category);
                ShopEditor.save();
                s.pendingConfirm = null;
                s.category = null;
                p.sendMessage("§a分类已删除");
                reopen(p, () -> ShopEditor.openRoot(p, s));
            }
            return;
        }
        if (slot == ShopEditor.BACK_SLOT) {
            s.category = null;
            s.content = null;
            s.tier = null;
            s.pendingConfirm = null;
            ShopEditor.openRoot(p, s);
            return;
        }
        if (slot == ShopEditor.CLOSE_SLOT) {
            p.closeInventory();
        }
    }

    private void handleContent(Player p, ShopEditor.Session s, InventoryClickEvent e, int slot) {
        List<String> tiers = ShopEditor.getTierNames(s.category, s.content);
        if (slot >= 0 && slot < 36 && slot < tiers.size()) {
            s.pendingConfirm = null;
            s.tier = tiers.get(slot);
            ShopEditor.openTier(p, s);
            return;
        }
        if (slot == ShopEditor.CONTENT_PERMANENT) {
            String node = ShopEditor.contentNode(s.category, s.content) + "." + ConfigPath.SHOP_CATEGORY_CONTENT_IS_PERMANENT;
            boolean cur = ShopEditor.yml().getBoolean(node, false);
            ShopEditor.yml().set(node, !cur);
            ShopEditor.save();
            reopen(p, () -> ShopEditor.openContent(p, s));
            return;
        }
        if (slot == ShopEditor.CONTENT_UNBREAKABLE) {
            String node = ShopEditor.contentNode(s.category, s.content) + "." + ConfigPath.SHOP_CATEGORY_CONTENT_IS_UNBREAKABLE;
            boolean cur = ShopEditor.yml().getBoolean(node, false);
            ShopEditor.yml().set(node, !cur);
            ShopEditor.save();
            reopen(p, () -> ShopEditor.openContent(p, s));
            return;
        }
        if (slot == ShopEditor.CONTENT_ADD_TIER) {
            s.pendingConfirm = null;
            int count = ShopEditor.getTierNames(s.category, s.content).size();
            String tierName = "tier" + (count + 1);
            ShopEditor.createTier(s.category, s.content, tierName);
            ShopEditor.save();
            p.sendMessage("§a已添加等级 " + tierName);
            reopen(p, () -> ShopEditor.openContent(p, s));
            return;
        }
        if (slot == ShopEditor.CONTENT_DELETE) {
            if (!"delete-content".equals(s.pendingConfirm)) {
                s.pendingConfirm = "delete-content";
                p.sendMessage("§c再次点击删除按钮确认删除商品 §f" + s.content);
            } else {
                ShopEditor.deleteContent(s.category, s.content);
                ShopEditor.save();
                s.pendingConfirm = null;
                s.content = null;
                s.tier = null;
                p.sendMessage("§a商品已删除");
                reopen(p, () -> ShopEditor.openCategory(p, s));
            }
            return;
        }
        if (slot == ShopEditor.BACK_SLOT) {
            s.content = null;
            s.tier = null;
            s.pendingConfirm = null;
            ShopEditor.openCategory(p, s);
            return;
        }
        if (slot == ShopEditor.CLOSE_SLOT) {
            p.closeInventory();
        }
    }

    private void handleTier(Player p, ShopEditor.Session s, InventoryClickEvent e, int slot) {
        String tierNode = ShopEditor.contentTierNode(s.category, s.content, s.tier);

        if (slot == ShopEditor.TIER_PREVIEW) {
            if (tryPlace(p, s, slot, e.getCursor())) {
                e.setCursor(null);
            }
            return;
        }
        if (slot == ShopEditor.TIER_BUY_ITEM) {
            if (tryPlace(p, s, slot, e.getCursor())) {
                e.setCursor(null);
            }
            return;
        }
        if (slot == ShopEditor.TIER_PRICE_DISPLAY) {
            s.awaiting = "price";
            p.closeInventory();
            p.sendMessage("§a请在聊天栏输入新的价格 (数字)，输入 cancel 取消");
            return;
        }
        if (slot == ShopEditor.TIER_PRICE_MINUS10 || slot == ShopEditor.TIER_PRICE_MINUS1
                || slot == ShopEditor.TIER_PRICE_PLUS1 || slot == ShopEditor.TIER_PRICE_PLUS10) {
            int delta = 0;
            if (slot == ShopEditor.TIER_PRICE_MINUS10) delta = -10;
            if (slot == ShopEditor.TIER_PRICE_MINUS1) delta = -1;
            if (slot == ShopEditor.TIER_PRICE_PLUS1) delta = 1;
            if (slot == ShopEditor.TIER_PRICE_PLUS10) delta = 10;
            int cur = ShopEditor.yml().getInt(tierNode + ConfigPath.SHOP_CONTENT_TIER_SETTINGS_COST, 0);
            int next = Math.max(0, cur + delta);
            ShopEditor.yml().set(tierNode + ConfigPath.SHOP_CONTENT_TIER_SETTINGS_COST, next);
            ShopEditor.save();
            reopen(p, () -> ShopEditor.openTier(p, s));
            return;
        }
        if (slot == ShopEditor.TIER_CURRENCY) {
            String cur = ShopEditor.yml().getString(tierNode + ConfigPath.SHOP_CONTENT_TIER_SETTINGS_CURRENCY, "iron");
            ShopEditor.yml().set(tierNode + ConfigPath.SHOP_CONTENT_TIER_SETTINGS_CURRENCY, ShopEditor.nextCurrency(cur));
            ShopEditor.save();
            reopen(p, () -> ShopEditor.openTier(p, s));
            return;
        }
        if (slot == ShopEditor.TIER_AUTO_EQUIP) {
            String node = tierNode + ".buy-items.item1.auto-equip";
            boolean cur = ShopEditor.yml().getBoolean(node, false);
            ShopEditor.yml().set(node, !cur);
            ShopEditor.save();
            reopen(p, () -> ShopEditor.openTier(p, s));
            return;
        }
        if (slot == ShopEditor.TIER_DELETE) {
            if (!"delete-tier".equals(s.pendingConfirm)) {
                s.pendingConfirm = "delete-tier";
                p.sendMessage("§c再次点击删除按钮确认删除等级 §f" + s.tier);
            } else {
                ShopEditor.deleteTier(s.category, s.content, s.tier);
                ShopEditor.save();
                s.pendingConfirm = null;
                s.tier = null;
                p.sendMessage("§a等级已删除");
                reopen(p, () -> ShopEditor.openContent(p, s));
            }
            return;
        }
        if (slot == ShopEditor.BACK_SLOT) {
            s.tier = null;
            s.pendingConfirm = null;
            ShopEditor.openContent(p, s);
            return;
        }
        if (slot == ShopEditor.CLOSE_SLOT) {
            p.closeInventory();
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDrag(InventoryDragEvent e) {
        if (!(e.getWhoClicked() instanceof Player)) return;
        Player p = (Player) e.getWhoClicked();
        ShopEditor.Session s = ShopEditor.getSession(p);
        if (s == null) return;
        if (!ShopEditor.isEditorInventory(e.getView())) return;

        // Editor inventories are locked; never let the client actually move items around.
        e.setCancelled(true);

        // Only support a simple single-slot drop onto the editor's top inventory.
        int topSize = e.getView().getTopInventory().getSize();
        int placeSlot = -1;
        for (int raw : e.getRawSlots()) {
            if (raw < topSize) {
                if (placeSlot != -1) return; // multi-slot drag, ignore
                placeSlot = raw;
            }
        }
        if (placeSlot == -1) return;

        ItemStack dragged = e.getOldCursor();
        if (dragged == null || dragged.getType() == Material.AIR) return;

        if (tryPlace(p, s, placeSlot, dragged)) {
            e.setCursor(null);
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getPlayer() instanceof Player)) return;
        Player p = (Player) e.getPlayer();
        if (!ShopEditor.isEditorInventory(e.getView())) return;
        ShopEditor.Session s = ShopEditor.getSession(p);
        if (s == null) return;
        if (s.awaiting != null) return;
        // Defer removal by one tick: navigating between editor screens also fires a
        // close event (openInventory swaps views). Only drop the session once the
        // player is truly out of the editor.
        Bukkit.getScheduler().runTask(BedWars.plugin, () -> {
            InventoryView v = p.getOpenInventory();
            if (v == null || !ShopEditor.isEditorInventory(v)) {
                ShopEditor.removeSession(p);
            }
        });
    }

    /**
     * Try to place the given item into a "drop target" slot of the current screen.
     * Returns true when the item was consumed into the shop config (and the UI reopened).
     */
    private boolean tryPlace(Player p, ShopEditor.Session s, int slot, ItemStack item) {
        if (item == null || item.getType() == Material.AIR) {
            p.sendMessage("§c请先用手拾取一个物品，再点击此槽位");
            return false;
        }
        if (s.category != null && s.content == null) {
            // category screen: category icon
            if (slot == ShopEditor.CATEGORY_ICON) {
                ShopEditor.writeItem(s.category + ".category-item", item);
                ShopEditor.save();
                p.sendMessage("§a分类图标已更新");
                reopen(p, () -> ShopEditor.openCategory(p, s));
                return true;
            }
        } else if (s.tier != null) {
            // tier screen: preview + buy item
            String tierNode = ShopEditor.contentTierNode(s.category, s.content, s.tier);
            if (slot == ShopEditor.TIER_PREVIEW) {
                ShopEditor.writeItem(tierNode + ".tier-item", item);
                ShopEditor.save();
                p.sendMessage("§a商店显示物品已更新");
                reopen(p, () -> ShopEditor.openTier(p, s));
                return true;
            }
            if (slot == ShopEditor.TIER_BUY_ITEM) {
                ShopEditor.writeBuyItem(tierNode + ".buy-items.item1", item);
                ShopEditor.save();
                p.sendMessage("§a购买物品已更新");
                reopen(p, () -> ShopEditor.openTier(p, s));
                return true;
            }
        }
        return false;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncPlayerChatEvent e) {
        final Player p = e.getPlayer();
        ShopEditor.Session s = ShopEditor.getSession(p);
        if (s == null || s.awaiting == null) return;

        final String message = e.getMessage();
        e.setCancelled(true);

        if (message.equalsIgnoreCase("cancel")) {
            s.awaiting = null;
            Bukkit.getScheduler().runTask(BedWars.plugin, () -> {
                p.sendMessage("§c已取消");
                if (s.category == null) {
                    ShopEditor.openRoot(p, s);
                } else if (s.content == null) {
                    ShopEditor.openCategory(p, s);
                } else if (s.tier == null) {
                    ShopEditor.openContent(p, s);
                } else {
                    ShopEditor.openTier(p, s);
                }
            });
            return;
        }

        Bukkit.getScheduler().runTask(BedWars.plugin, () -> ShopEditor.onChat(p, message));
    }

    private static void reopen(Player p, Runnable r) {
        Bukkit.getScheduler().runTask(BedWars.plugin, r);
    }
}
